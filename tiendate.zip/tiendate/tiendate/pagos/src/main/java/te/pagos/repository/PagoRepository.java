package te.pagos.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import te.pagos.model.Pago;

@Repository
public interface PagoRepository extends JpaRepository<Pago, Long> {
    // Para buscar el comprobante de pago asociado a una venta específica
    Optional<Pago> findByVentaId(Long ventaId);
}