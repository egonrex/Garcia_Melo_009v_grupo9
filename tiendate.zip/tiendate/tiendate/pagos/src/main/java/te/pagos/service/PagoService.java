package te.pagos.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.pagos.model.Pago;
import te.pagos.repository.PagoRepository;

@Service
public class PagoService {

    @Autowired
    private PagoRepository pagoRepository;

    public List<Pago> listarTodos() {
        return pagoRepository.findAll();
    }

    public Optional<Pago> buscarPorId(Long id) {
        return pagoRepository.findById(id);
    }

    public Optional<Pago> buscarPorVentaId(Long ventaId) {
        return pagoRepository.findByVentaId(ventaId);
    }

    public Pago procesarPago(Pago pago) {
        if (pago.getFechaTransaccion() == null) {
            pago.setFechaTransaccion(LocalDateTime.now());
        }
        // Asumimos que si entra el registro, se asume aprobado por defecto salvo que se indique lo contrario
        if (pago.getEstado() == null || pago.getEstado().isEmpty()) {
            pago.setEstado("APROBADO");
        }
        return pagoRepository.save(pago);
    }

    public void eliminar(Long id) {
        pagoRepository.deleteById(id);
    }
}