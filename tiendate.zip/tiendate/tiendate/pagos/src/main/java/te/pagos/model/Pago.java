package te.pagos.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "pagos")
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long ventaId; // Para saber qué venta se está pagando

    @Column(nullable = false)
    private Integer monto;

    @Column(length = 50)
    private String metodoPago; // Ej: WEBPAY, TRANSFERENCIA, EFECTIVO

    @Column(length = 50)
    private String estado; // Ej: APROBADO, RECHAZADO

    @Column(nullable = false)
    private LocalDateTime fechaTransaccion;

    // Constructores
    public Pago() {}

    public Pago(Long id, Long ventaId, Integer monto, String metodoPago, String estado, LocalDateTime fechaTransaccion) {
        this.id = id;
        this.ventaId = ventaId;
        this.monto = monto;
        this.metodoPago = metodoPago;
        this.estado = estado;
        this.fechaTransaccion = fechaTransaccion;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getVentaId() { return ventaId; }
    public void setVentaId(Long ventaId) { this.ventaId = ventaId; }

    public Integer getMonto() { return monto; }
    public void setMonto(Integer monto) { this.monto = monto; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public LocalDateTime getFechaTransaccion() { return fechaTransaccion; }
    public void setFechaTransaccion(LocalDateTime fechaTransaccion) { this.fechaTransaccion = fechaTransaccion; }
}