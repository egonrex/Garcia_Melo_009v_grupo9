package te.cupones.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import te.cupones.model.Cupon;

@Repository
public interface CuponRepository extends JpaRepository<Cupon, Long> {
    // Método personalizado para buscar el cupón por la palabra clave
    Optional<Cupon> findByCodigo(String codigo);
}