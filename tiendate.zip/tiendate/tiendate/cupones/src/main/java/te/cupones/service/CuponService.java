package te.cupones.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.cupones.model.Cupon;
import te.cupones.repository.CuponRepository;

@Service
public class CuponService {

    @Autowired
    private CuponRepository cuponRepository;

    public List<Cupon> listarTodos() {
        return cuponRepository.findAll();
    }

    public Optional<Cupon> buscarPorId(Long id) {
        return cuponRepository.findById(id);
    }

    public Optional<Cupon> buscarPorCodigo(String codigo) {
        return cuponRepository.findByCodigo(codigo);
    }

    public Cupon guardar(Cupon cupon) {
        return cuponRepository.save(cupon);
    }

    public void eliminar(Long id) {
        cuponRepository.deleteById(id);
    }
}