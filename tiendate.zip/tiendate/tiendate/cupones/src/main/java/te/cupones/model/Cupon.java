package te.cupones.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "cupones")
public class Cupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50, unique = true)
    private String codigo; // Ej: VERANO20, CLIENTEFRECUENTE

    @Column(nullable = false)
    private Integer porcentaje; // Ej: 15 (para 15% de descuento)

    @Column(nullable = false)
    private Boolean activo; // true si se puede usar, false si ya expiró

    // Constructores
    public Cupon() {}

    public Cupon(Long id, String codigo, Integer porcentaje, Boolean activo) {
        this.id = id;
        this.codigo = codigo;
        this.porcentaje = porcentaje;
        this.activo = activo;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public Integer getPorcentaje() { return porcentaje; }
    public void setPorcentaje(Integer porcentaje) { this.porcentaje = porcentaje; }

    public Boolean getActivo() { return activo; }
    public void setActivo(Boolean activo) { this.activo = activo; }
}