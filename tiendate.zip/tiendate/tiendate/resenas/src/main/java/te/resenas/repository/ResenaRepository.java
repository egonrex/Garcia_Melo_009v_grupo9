package te.resenas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import te.resenas.model.Resena;

@Repository
public interface ResenaRepository extends JpaRepository<Resena, Long> {
    // Buscar todas las reseñas de un producto en específico para mostrarlas en su página
    List<Resena> findByProductoId(Long productoId);
}