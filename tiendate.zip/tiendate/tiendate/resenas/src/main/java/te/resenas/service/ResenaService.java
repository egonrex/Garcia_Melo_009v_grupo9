package te.resenas.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.resenas.model.Resena;
import te.resenas.repository.ResenaRepository;

@Service
public class ResenaService {

    @Autowired
    private ResenaRepository resenaRepository;

    public List<Resena> listarTodas() {
        return resenaRepository.findAll();
    }

    public Optional<Resena> buscarPorId(Long id) {
        return resenaRepository.findById(id);
    }

    public List<Resena> buscarPorProductoId(Long productoId) {
        return resenaRepository.findByProductoId(productoId);
    }

    public Resena guardar(Resena resena) {
        if (resena.getFechaResena() == null) {
            resena.setFechaResena(LocalDateTime.now());
        }
        return resenaRepository.save(resena);
    }

    public void eliminar(Long id) {
        resenaRepository.deleteById(id);
    }
}