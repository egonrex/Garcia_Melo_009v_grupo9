package te.envios.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.envios.model.Envio;
import te.envios.repository.EnvioRepository;

@Service
public class EnvioService {

    @Autowired
    private EnvioRepository envioRepository;

    public List<Envio> listarTodos() {
        return envioRepository.findAll();
    }

    public Optional<Envio> buscarPorId(Long id) {
        return envioRepository.findById(id);
    }

    public Optional<Envio> buscarPorVentaId(Long ventaId) {
        return envioRepository.findByVentaId(ventaId);
    }

    public Envio crearEnvio(Envio envio) {
        // Al crearse el envío, su estado por defecto es PREPARANDO
        if (envio.getEstado() == null || envio.getEstado().isEmpty()) {
            envio.setEstado("PREPARANDO");
        }
        return envioRepository.save(envio);
    }

    public void eliminar(Long id) {
        envioRepository.deleteById(id);
    }
}