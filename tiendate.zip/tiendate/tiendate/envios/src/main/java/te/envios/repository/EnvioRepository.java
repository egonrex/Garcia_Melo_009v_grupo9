package te.envios.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import te.envios.model.Envio;

@Repository
public interface EnvioRepository extends JpaRepository<Envio, Long> {
    // Buscar el estado del envío usando el ID de la compra
    Optional<Envio> findByVentaId(Long ventaId);
}