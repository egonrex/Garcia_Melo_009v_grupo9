package te.ventas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import te.ventas.model.Venta;

@Repository
public interface VentaRepository extends JpaRepository<Venta, Long> {
    // Método para ver el historial de compras de un cliente específico
    List<Venta> findByUsuarioId(Long usuarioId);
}