package te.carrito.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import te.carrito.model.Carrito;

@Repository
public interface CarritoRepository extends JpaRepository<Carrito, Long> {
    // Buscar todos los items en el carrito de un usuario
    List<Carrito> findByUsuarioId(Long usuarioId);
}