package te.principal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import te.principal.model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {
    // Método personalizado para filtrar el catálogo
    List<Producto> findByCategoria(String categoria);
}