package te.proovedores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProovedoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProovedoresApplication.class, args);
	}

}
