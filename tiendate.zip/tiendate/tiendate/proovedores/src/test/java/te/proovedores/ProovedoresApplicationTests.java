package te.proovedores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProovedoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
