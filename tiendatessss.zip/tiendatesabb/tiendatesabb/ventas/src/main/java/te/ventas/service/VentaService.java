package te.ventas.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.ventas.client.CarritoClient;
import java.util.Map;
import te.ventas.client.CuponClient;
import te.ventas.client.EnvioClient;
import te.ventas.client.ProductoClient;
import te.ventas.client.ResenaClient;
import te.ventas.client.UsuarioClient;
import te.ventas.dto.CarritoDTO;
import te.ventas.dto.CheckoutRequest;
import te.ventas.dto.CuponDTO;
import te.ventas.dto.EnvioDTO;
import te.ventas.dto.ProductoDTO;
import te.ventas.dto.UsuarioDTO;
import te.ventas.model.Venta;
import te.ventas.model.VentaDetalle;
import te.ventas.repository.VentaRepository;
import te.ventas.repository.VentaDetalleRepository;

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private VentaDetalleRepository detalleRepository;

    @Autowired
    private CarritoClient carritoClient;

    @Autowired
    private ProductoClient productoClient;

    @Autowired
    private CuponClient cuponClient;

    @Autowired
    private UsuarioClient usuarioClient;

    @Autowired
    private EnvioClient envioClient;

    @Autowired
    private ResenaClient resenaClient;

    public List<Venta> listarTodas() {
        return ventaRepository.findAll();
    }

    public Optional<Venta> buscarPorId(Long id) {
        return ventaRepository.findById(id);
    }

    public List<Venta> historialPorUsuario(Long usuarioId) {
        return ventaRepository.findByUsuarioId(usuarioId);
    }

    public Venta crearVenta(Venta venta) {
        if (venta.getFechaVenta() == null) {
            venta.setFechaVenta(LocalDateTime.now());
        }
        if (venta.getEstado() == null || venta.getEstado().isEmpty()) {
            venta.setEstado("PENDIENTE");
        }
        return ventaRepository.save(venta);
    }

    public Venta procesarCheckout(CheckoutRequest request) {
        List<CarritoDTO> itemsCarrito = carritoClient.obtenerPorUsuario(request.getUsuarioId());
        
        if (itemsCarrito == null || itemsCarrito.isEmpty()) {
            throw new IllegalStateException("El carrito está vacío. No se puede procesar la venta.");
        }

        int totalVenta = 0;
        for (CarritoDTO item : itemsCarrito) {
            ProductoDTO producto = productoClient.obtenerPorId(item.getProductoId());
            if (producto.getStock() < item.getCantidad()) {
                throw new IllegalStateException("Stock insuficiente para el producto ID: " + item.getProductoId());
            }
            totalVenta += (producto.getPrecio() * item.getCantidad());
        }

        if (request.getCodigoCupon() != null && !request.getCodigoCupon().trim().isEmpty()) {
            CuponDTO cupon = cuponClient.obtenerPorCodigo(request.getCodigoCupon());
            if (cupon != null && cupon.getActivo()) {
                totalVenta -= (totalVenta * cupon.getPorcentaje()) / 100;
            }
        }

        Venta nuevaVenta = new Venta();
        nuevaVenta.setUsuarioId(request.getUsuarioId());
        nuevaVenta.setTotal(totalVenta);
        nuevaVenta.setEstado("PENDIENTE");
        nuevaVenta.setFechaVenta(LocalDateTime.now());
        Venta ventaGuardada = ventaRepository.save(nuevaVenta);

        for (CarritoDTO item : itemsCarrito) {
            ProductoDTO producto = productoClient.obtenerPorId(item.getProductoId());
            VentaDetalle detalle = new VentaDetalle();
            detalle.setVentaId(ventaGuardada.getId());
            detalle.setProductoId(item.getProductoId());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(producto.getPrecio());
            detalleRepository.save(detalle);
            
            carritoClient.eliminarItem(item.getId());
        }

        return ventaGuardada;
    }

    // Regla de Negocio 2: Actualizar estado desde Pagos (Actualizado con Envíos)
    public Venta actualizarEstado(Long id, String nuevoEstado) {
        Venta venta = ventaRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Venta no encontrada con ID: " + id));
        
        venta.setEstado(nuevoEstado);
        Venta ventaActualizada = ventaRepository.save(venta);

        // Si se confirma el pago, suceden dos cosas mágicas
        if ("ENTREGADO".equals(nuevoEstado)) {
    List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
    for (VentaDetalle detalle : detalles) {
        try {
            // Enviamos el usuario y producto para que Reseñas sepa qué habilitar
            Map<String, Object> data = Map.of(
                "usuarioId", venta.getUsuarioId(),
                "productoId", detalle.getProductoId()
            );
            resenaClient.habilitarResena(data);
        } catch (Exception e) {
            System.err.println("No se pudo habilitar reseña: " + e.getMessage());
        }
    }
}

        if ("PAGADO".equals(nuevoEstado)) {
            // Magia 1: Descontar stock de forma síncrona
            List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
            for (VentaDetalle detalle : detalles) {
                productoClient.descontarStock(detalle.getProductoId(), detalle.getCantidad());
            }
            
            // Magia 2: Preguntar al Usuario su dirección y ordenar el Envío
            try {
                UsuarioDTO usuario = usuarioClient.obtenerPorId(venta.getUsuarioId());
                
                EnvioDTO nuevoEnvio = new EnvioDTO();
                nuevoEnvio.setVentaId(venta.getId());
                // Validamos por si el usuario no rellenó su dirección al registrarse
                nuevoEnvio.setDireccionEntrega(usuario.getDireccion() != null ? usuario.getDireccion() : "Dirección Pendiente");
                
                envioClient.crearEnvio(nuevoEnvio);
            } catch (Exception e) {
                System.err.println("Advertencia: No se pudo generar el envío automático para la venta " + id + ". Detalle: " + e.getMessage());
            }
        }

        return ventaActualizada;
    }

    public void eliminar(Long id) {
        ventaRepository.deleteById(id);
    }
}