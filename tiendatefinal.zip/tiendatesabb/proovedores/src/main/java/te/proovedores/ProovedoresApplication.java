package te.proovedores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ProovedoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProovedoresApplication.class, args);
	}

}
