package te.principal.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import te.principal.dto.ProveedorDTO;

@FeignClient(name = "proovedores") // Debe coincidir con el spring.application.name del microservicio de proveedores
public interface ProveedorClient {

    @GetMapping("/api/proveedores/{id}")
    ProveedorDTO obtenerPorId(@PathVariable("id") Long id);
}