package te.principal.repository;

import java.util.List;
import java.util.Optional; // Asegúrate de importar Optional
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import te.principal.model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {
    List<Producto> findByCategoria(String categoria);
    
    // Añade esta línea:
    Optional<Producto> findByNombre(String nombre);
}