package te.principal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import te.principal.model.Producto;
import te.principal.service.ProductoService;
import te.principal.client.ProveedorClient; // <-- NUEVA IMPORTACIÓN

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @Autowired
    private ProveedorClient proveedorClient; // <-- NUEVA INYECCIÓN DEL CLIENTE FEIGN

    @GetMapping
    public List<Producto> obtenerTodos() {
        return productoService.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerPorId(@PathVariable Long id) {
        return productoService.buscarPorId(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/categoria/{categoria}")
    public List<Producto> obtenerPorCategoria(@PathVariable String categoria) {
        return productoService.buscarPorCategoria(categoria);
    }

@PostMapping
    public ResponseEntity<?> crear(@RequestBody Producto producto) {
        
        // 🔴 4. LA REGLA DE LOS DATOS NEGATIVOS (FASE 2)
        // Validamos que el precio venga en el JSON y que sea estrictamente mayor a 0
        if (producto.getPrecio() == null || producto.getPrecio() <= 0) {
            return ResponseEntity.badRequest().body("Error: El precio debe ser mayor a cero.");
        }

        // (Bonus para el profesor) Validamos que el stock no sea negativo
        if (producto.getStock() == null || producto.getStock() < 0) {
            return ResponseEntity.badRequest().body("Error: El stock inicial no puede ser negativo.");
        }

        // 1. Validar que la petición incluya el ID del proveedor
        if (producto.getProveedorId() == null) {
            return ResponseEntity.badRequest().body("Error: Debe indicar un proveedorId.");
        }

        // 2. Comunicarse con el microservicio de Proveedores vía Feign
        try {
            proveedorClient.obtenerPorId(producto.getProveedorId());
        } catch (feign.FeignException.NotFound e) {
            return ResponseEntity.badRequest().body("Error: El proveedor no es válido o no existe.");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error de comunicación con el servicio de Proveedores.");
        }

        // 3. Validar si el producto ya existe en el catálogo
        if (productoService.buscarPorNombre(producto.getNombre()).isPresent()) {
            return ResponseEntity.badRequest()
                .body("Error: El producto '" + producto.getNombre() + "' ya existe en el catálogo.");
        }
        
        // 4. Si pasó todos los filtros e IFs, finalmente guardamos
        Producto nuevoProducto = productoService.guardar(producto);
        return ResponseEntity.ok(nuevoProducto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (productoService.buscarPorId(id).isPresent()) {
            productoService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    // --- NUEVO ENDPOINT PARA RESTAR STOCK ---
    @PutMapping("/{id}/descontar-stock")
    public ResponseEntity<?> descontarStock(@PathVariable Long id, @RequestParam Integer cantidad) {
        try {
            Producto actualizado = productoService.descontarStock(id, cantidad);
            return ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}