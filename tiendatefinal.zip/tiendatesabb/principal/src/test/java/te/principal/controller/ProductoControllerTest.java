package te.principal.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import feign.FeignException;
import te.principal.client.ProveedorClient;
import te.principal.dto.ProveedorDTO;
import te.principal.model.Producto;
import te.principal.service.ProductoService;

@ExtendWith(MockitoExtension.class)
public class ProductoControllerTest {

    @InjectMocks
    private ProductoController productoController;

    @Mock
    private ProductoService productoService;

    @Mock
    private ProveedorClient proveedorClient;

    @Test
    void crearProducto_CasoFeliz() {
        // --- ARRANGE (Preparar) ---
        Producto productoRequest = new Producto();
        productoRequest.setNombre("Té Verde Matcha");
        productoRequest.setPrecio(5000); // Mayor a 0
        productoRequest.setStock(20);    // Mayor a 0
        productoRequest.setProveedorId(1L); // Proveedor asignado

        ProveedorDTO proveedorFalso = new ProveedorDTO();
        proveedorFalso.setId(1L);

        Producto productoGuardado = new Producto();
        productoGuardado.setId(10L);
        productoGuardado.setNombre("Té Verde Matcha");

        // Simulamos que el proveedor existe y que el nombre no está duplicado
        when(proveedorClient.obtenerPorId(1L)).thenReturn(proveedorFalso);
        when(productoService.buscarPorNombre("Té Verde Matcha")).thenReturn(Optional.empty());
        when(productoService.guardar(any(Producto.class))).thenReturn(productoGuardado);

        // --- ACT (Actuar) ---
        ResponseEntity<?> response = productoController.crear(productoRequest);

        // --- ASSERT (Afirmar) ---
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(productoGuardado, response.getBody());
        
        // Verificamos que efectivamente se llamó al método guardar
        verify(productoService, times(1)).guardar(productoRequest);
    }

    @Test
    void crearProducto_ErrorPrecioCeroONegativo() {
        // --- ARRANGE ---
        Producto productoRequest = new Producto();
        productoRequest.setPrecio(0); // Cero o negativo detona el error

        // --- ACT ---
        ResponseEntity<?> response = productoController.crear(productoRequest);

        // --- ASSERT ---
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Error: El precio debe ser mayor a cero.", response.getBody());
        
        // Verificamos que el proceso se detuvo y NUNCA se consultó al proveedor ni se guardó nada
        verifyNoInteractions(proveedorClient, productoService);
    }

    @Test
    void crearProducto_ErrorStockNegativo() {
        // --- ARRANGE ---
        Producto productoRequest = new Producto();
        productoRequest.setPrecio(5000); // Precio válido
        productoRequest.setStock(-5);    // Stock negativo detona el error

        // --- ACT ---
        ResponseEntity<?> response = productoController.crear(productoRequest);

        // --- ASSERT ---
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Error: El stock inicial no puede ser negativo.", response.getBody());
        verifyNoInteractions(proveedorClient, productoService);
    }

    @Test
    void crearProducto_ErrorSinProveedorId() {
        // --- ARRANGE ---
        Producto productoRequest = new Producto();
        productoRequest.setPrecio(5000);
        productoRequest.setStock(10);
        productoRequest.setProveedorId(null); // Sin proveedor

        // --- ACT ---
        ResponseEntity<?> response = productoController.crear(productoRequest);

        // --- ASSERT ---
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Error: Debe indicar un proveedorId.", response.getBody());
        verifyNoInteractions(proveedorClient, productoService);
    }

    @Test
    void crearProducto_ErrorProveedorNoExiste() {
        // --- ARRANGE ---
        Producto productoRequest = new Producto();
        productoRequest.setPrecio(5000);
        productoRequest.setStock(10);
        productoRequest.setProveedorId(99L); // Proveedor que no existe

        // Simulamos el error 404 que arrojaría Feign
        FeignException.NotFound notFound = mock(FeignException.NotFound.class);
        when(proveedorClient.obtenerPorId(99L)).thenThrow(notFound);

        // --- ACT ---
        ResponseEntity<?> response = productoController.crear(productoRequest);

        // --- ASSERT ---
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Error: El proveedor no es válido o no existe.", response.getBody());
        
        // Verificamos que no se guardó el producto
        verifyNoInteractions(productoService);
    }

    @Test
    void crearProducto_ErrorProductoDuplicado() {
        // --- ARRANGE ---
        Producto productoRequest = new Producto();
        productoRequest.setNombre("Té Duplicado");
        productoRequest.setPrecio(5000);
        productoRequest.setStock(10);
        productoRequest.setProveedorId(1L);

        ProveedorDTO proveedorFalso = new ProveedorDTO();
        when(proveedorClient.obtenerPorId(1L)).thenReturn(proveedorFalso);
        
        // Simulamos que la base de datos ya tiene un producto con ese nombre
        when(productoService.buscarPorNombre("Té Duplicado")).thenReturn(Optional.of(new Producto()));

        // --- ACT ---
        ResponseEntity<?> response = productoController.crear(productoRequest);

        // --- ASSERT ---
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Error: El producto 'Té Duplicado' ya existe en el catálogo.", response.getBody());
        
        // Verificamos que NO se llamó al método guardar
        verify(productoService, never()).guardar(any(Producto.class));
    }
}