package te.pagos.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.pagos.client.VentaClient;
import te.pagos.model.Pago;
import te.pagos.repository.PagoRepository;

@Service
public class PagoService {

    @Autowired
    private PagoRepository pagoRepository;

    @Autowired
    private VentaClient ventaClient;

    public List<Pago> listarTodos() {
        return pagoRepository.findAll();
    }

    public Optional<Pago> buscarPorId(Long id) {
        return pagoRepository.findById(id);
    }

    public Optional<Pago> buscarPorVentaId(Long ventaId) {
        return pagoRepository.findByVentaId(ventaId);
    }

    public Pago procesarPago(Pago pago) {
        if (pago.getFechaTransaccion() == null) {
            pago.setFechaTransaccion(LocalDateTime.now());
        }
        
        if (pago.getEstado() == null || pago.getEstado().isEmpty()) {
            pago.setEstado("APROBADO");
        }
        
        Pago pagoGuardado = pagoRepository.save(pago);

        // REGLA DE NEGOCIO: Si el pago es exitoso, actualizar Venta y descontar stock
        if ("APROBADO".equals(pagoGuardado.getEstado())) {
            try {
                // 1. Marcar la orden como PAGADA en el microservicio de Ventas
                ventaClient.actualizarEstado(pagoGuardado.getVentaId(), "PAGADO");
                
                // 2. Descontar Stock (Nota Arquitectónica)
                // TODO: Para descontar stock, se requiere implementar un modelo de 'VentaDetalle' 
                // en la BBDD de Ventas, consultar los items aquí y enviar la petición a Principal.
                
            } catch (Exception e) {
                // Alerta en caso de falla de comunicación
                throw new RuntimeException("El pago fue aprobado localmente, pero falló la comunicación con Ventas: " + e.getMessage());
            }
        }
        
        return pagoGuardado;
    }

    public void eliminar(Long id) {
        pagoRepository.deleteById(id);
    }
}