package te.pagos.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "ventas")
public interface VentaClient {

    @PutMapping("/api/ventas/{id}/estado")
    void actualizarEstado(@PathVariable("id") Long id, @RequestParam("estado") String estado);
}