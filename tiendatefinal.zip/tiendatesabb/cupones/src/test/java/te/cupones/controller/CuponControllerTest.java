package te.cupones.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import te.cupones.model.Cupon;
import te.cupones.service.CuponService;

@ExtendWith(MockitoExtension.class)
public class CuponControllerTest {

    @InjectMocks
    private CuponController cuponController;

    @Mock
    private CuponService cuponService;

    @Test
    void obtenerPorCodigo_CasoFeliz_CuponExisteYActivo() {
        // --- ARRANGE (Preparar) ---
        Cupon cuponActivo = new Cupon();
        cuponActivo.setId(1L);
        cuponActivo.setCodigo("DESCUENTO20");
        cuponActivo.setPorcentaje(20);
        cuponActivo.setActivo(true); // Cupón vigente

        when(cuponService.buscarPorCodigo("DESCUENTO20")).thenReturn(Optional.of(cuponActivo));

        // --- ACT (Actuar) ---
        ResponseEntity<Cupon> response = cuponController.obtenerPorCodigo("DESCUENTO20");

        // --- ASSERT (Afirmar) ---
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().getActivo());
        assertEquals("DESCUENTO20", response.getBody().getCodigo());

        verify(cuponService, times(1)).buscarPorCodigo("DESCUENTO20");
    }

    @Test
    void obtenerPorCodigo_Error_CuponNoExiste() {
        // --- ARRANGE ---
        // Simulamos que la base de datos no encuentra nada y devuelve un Optional vacío
        when(cuponService.buscarPorCodigo("FALSO")).thenReturn(Optional.empty());

        // --- ACT ---
        ResponseEntity<Cupon> response = cuponController.obtenerPorCodigo("FALSO");

        // --- ASSERT ---
        // Verificamos que el controlador arroje el código HTTP 404 (Not Found)
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());

        verify(cuponService, times(1)).buscarPorCodigo("FALSO");
    }

    @Test
    void obtenerPorCodigo_Regla_CuponExistePeroInactivo() {
        // --- ARRANGE ---
        Cupon cuponInactivo = new Cupon();
        cuponInactivo.setId(2L);
        cuponInactivo.setCodigo("EXPIRADO");
        cuponInactivo.setPorcentaje(10);
        cuponInactivo.setActivo(false); // Cupón Inactivo

        when(cuponService.buscarPorCodigo("EXPIRADO")).thenReturn(Optional.of(cuponInactivo));

        // --- ACT ---
        ResponseEntity<Cupon> response = cuponController.obtenerPorCodigo("EXPIRADO");

        // --- ASSERT ---
        // Nota arquitectónica: Cupones sí devuelve un 200 OK porque el recurso existe, 
        // pero verificamos que viaje con la etiqueta 'false' para que Ventas rechace la transacción.
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertFalse(response.getBody().getActivo()); // Garantizamos que viaje como inactivo

        verify(cuponService, times(1)).buscarPorCodigo("EXPIRADO");
    }
}
