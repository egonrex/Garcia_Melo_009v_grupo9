package te.cupones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class CuponesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuponesApplication.class, args);
	}

}
