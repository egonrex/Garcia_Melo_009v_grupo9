package te.ventas.dto;

import lombok.Data;

@Data
public class EnvioDTO {
    private Long ventaId;
    private String direccionEntrega;
    private String estado;
}