package te.ventas.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.Map;

@FeignClient(name = "resenas")
public interface ResenaClient {
    // Este endpoint permitirá que Ventas notifique a Reseñas que un producto fue comprado
    @PostMapping("/api/resenas/habilitar")
    void habilitarResena(@RequestBody Map<String, Object> data);
}