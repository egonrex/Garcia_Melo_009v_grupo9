package te.ventas.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import te.ventas.dto.CuponDTO;

@FeignClient(name = "cupones")
public interface CuponClient {

    @GetMapping("/api/cupones/codigo/{codigo}")
    CuponDTO obtenerPorCodigo(@PathVariable("codigo") String codigo);
}