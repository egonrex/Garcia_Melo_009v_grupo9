package te.ventas.dto;

import lombok.Data;

@Data
public class CuponDTO {
    private Integer porcentaje;
    private Boolean activo;
}