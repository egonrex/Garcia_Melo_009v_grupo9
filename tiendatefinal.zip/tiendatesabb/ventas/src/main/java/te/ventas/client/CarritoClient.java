package te.ventas.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import te.ventas.dto.CarritoDTO;

@FeignClient(name = "carrito")
public interface CarritoClient {

    @GetMapping("/api/carrito/usuario/{usuarioId}")
    List<CarritoDTO> obtenerPorUsuario(@PathVariable("usuarioId") Long usuarioId);

    @DeleteMapping("/api/carrito/{id}")
    void eliminarItem(@PathVariable("id") Long id);
}