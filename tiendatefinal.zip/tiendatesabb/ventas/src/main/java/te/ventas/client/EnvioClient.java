package te.ventas.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import te.ventas.dto.EnvioDTO;

@FeignClient(name = "envios")
public interface EnvioClient {

    @PostMapping("/api/envios")
    EnvioDTO crearEnvio(@RequestBody EnvioDTO envio);
}