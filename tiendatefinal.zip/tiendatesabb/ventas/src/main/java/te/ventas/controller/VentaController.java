package te.ventas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import te.ventas.dto.CheckoutRequest;
import te.ventas.model.Venta;
import te.ventas.service.VentaService;

@RestController
@RequestMapping("/api/ventas")
public class VentaController {

    @Autowired
    private VentaService ventaService;

    @GetMapping
    public List<Venta> obtenerTodas() {
        return ventaService.listarTodas();
    }

    @GetMapping("/usuario/{usuarioId}")
    public List<Venta> obtenerPorUsuario(@PathVariable Long usuarioId) {
        return ventaService.historialPorUsuario(usuarioId);
    }

// 🔴 5. LA REGLA DE LAS BÚSQUEDAS QUE NO EXISTEN
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerPorId(@PathVariable Long id) {
        // 1. Buscamos el contenedor Optional en el servicio
        java.util.Optional<Venta> ventaOptional = ventaService.buscarPorId(id);
        
        // 2. El IF: Evaluamos si el registro NO está presente en la base de datos
        if (ventaOptional.isEmpty()) {
            // Retornamos un estado 404 (Not Found) con el mensaje de error personalizado
            return ResponseEntity.status(404).body("Error: La venta no existe.");
        }
        
        // 3. Si pasa el IF, significa que sí existe y podemos desenvolver el objeto de forma segura (.get())
        return ResponseEntity.ok(ventaOptional.get());
    }

    @PostMapping
    public Venta crear(@RequestBody Venta venta) {
        return ventaService.crearVenta(venta);
    }

    @PostMapping("/checkout")
    public ResponseEntity<?> realizarCheckout(@RequestBody CheckoutRequest request) {
        try {
            Venta nuevaVenta = ventaService.procesarCheckout(request);
            return ResponseEntity.ok(nuevaVenta);
        } catch (IllegalStateException | IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body("Error interno procesando el checkout.");
        }
    }

    @PutMapping("/{id}/estado")
    public ResponseEntity<?> actualizarEstado(@PathVariable Long id, @RequestParam String estado) {
        try {
            Venta ventaActualizada = ventaService.actualizarEstado(id, estado);
            return ResponseEntity.ok(ventaActualizada);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al actualizar el estado");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (ventaService.buscarPorId(id).isPresent()) {
            ventaService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}