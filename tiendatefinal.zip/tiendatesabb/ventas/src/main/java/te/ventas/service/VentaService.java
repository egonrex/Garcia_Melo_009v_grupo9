package te.ventas.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.ventas.client.CarritoClient;
import te.ventas.client.CuponClient;
import te.ventas.client.EnvioClient;
import te.ventas.client.ProductoClient;
import te.ventas.client.ResenaClient;
import te.ventas.client.UsuarioClient;
import te.ventas.dto.CarritoDTO;
import te.ventas.dto.CheckoutRequest;
import te.ventas.dto.CuponDTO;
import te.ventas.dto.EnvioDTO;
import te.ventas.dto.ProductoDTO;
import te.ventas.dto.UsuarioDTO;
import te.ventas.model.Venta;
import te.ventas.model.VentaDetalle;
import te.ventas.repository.VentaDetalleRepository;
import te.ventas.repository.VentaRepository;

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private VentaDetalleRepository detalleRepository;

    @Autowired
    private CarritoClient carritoClient;

    @Autowired
    private ProductoClient productoClient;

    @Autowired
    private CuponClient cuponClient;

    @Autowired
    private UsuarioClient usuarioClient;

    @Autowired
    private EnvioClient envioClient;

    @Autowired
    private ResenaClient resenaClient;

    public List<Venta> listarTodas() {
        return ventaRepository.findAll();
    }

    public Optional<Venta> buscarPorId(Long id) {
        return ventaRepository.findById(id);
    }

    public List<Venta> historialPorUsuario(Long usuarioId) {
        return ventaRepository.findByUsuarioId(usuarioId);
    }

    public Venta crearVenta(Venta venta) {
        if (venta.getFechaVenta() == null) {
            venta.setFechaVenta(LocalDateTime.now());
        }
        if (venta.getEstado() == null || venta.getEstado().isEmpty()) {
            venta.setEstado("PENDIENTE");
        }
        return ventaRepository.save(venta);
    }

public Venta procesarCheckout(CheckoutRequest request) {
        List<CarritoDTO> itemsCarrito = carritoClient.obtenerPorUsuario(request.getUsuarioId());

        if (itemsCarrito == null || itemsCarrito.isEmpty()) {
            throw new IllegalStateException("El carrito está vacío. No se puede procesar la venta.");
        }

        List<ProductoDTO> productosResueltos = new ArrayList<>();
        int totalVenta = 0;
        
        for (CarritoDTO item : itemsCarrito) {
            ProductoDTO producto;
            try {
                producto = productoClient.obtenerPorId(item.getProductoId());
            } catch (feign.FeignException.NotFound e) {
                throw new IllegalStateException(
                        "Error: El producto con ID " + item.getProductoId() + " que está en el carrito ya no existe.");
            }

            // 🔴 1. LA REGLA DEL STOCK (FASE 2: BLINDAR EL SISTEMA)
            if (item.getCantidad() > producto.getStock()) {
                // Lanzamos el error con la explicación detallada
                throw new IllegalStateException(
                    "Error: No hay stock suficiente. Intentas comprar " + item.getCantidad() + 
                    " unidades, pero solo quedan " + producto.getStock() + 
                    " en el inventario (Producto ID: " + item.getProductoId() + ")."
                );
            }

            totalVenta += (producto.getPrecio() * item.getCantidad());
            productosResueltos.add(producto); // guardamos para la segunda pasada
        }

        // 🔴 3. LA REGLA DEL CUPÓN FALSO O EXPIRADO (FASE 2)
        if (request.getCodigoCupon() != null && !request.getCodigoCupon().trim().isEmpty()) {
            try {
                // Feign buscará el cupón en el microservicio de Cupones
                CuponDTO cupon = cuponClient.obtenerPorCodigo(request.getCodigoCupon());
                
                // Si el cupón existe pero está inactivo (expirado o falso)
                if (cupon == null || Boolean.FALSE.equals(cupon.getActivo())) {
                    throw new IllegalStateException("El cupón no es válido o ya expiró");
                }
                
                // Si llegamos hasta aquí, el cupón es válido y está activo: ¡Aplicamos descuento!
                totalVenta -= (totalVenta * cupon.getPorcentaje()) / 100;
                
        } catch (feign.FeignException.NotFound e) {
            throw new IllegalStateException("El cupón no es válido o ya expiró");
        } catch (IllegalStateException e) {
            throw e; // <-- AGREGA ESTO: Deja pasar tu propio error sin cambiarle el mensaje
        } catch (Exception e) {
            throw new IllegalStateException("Error al validar el cupón. Intente nuevamente.");
        }
        }

        // Guardamos la venta cabecera
        Venta nuevaVenta = new Venta();
        nuevaVenta.setUsuarioId(request.getUsuarioId());
        nuevaVenta.setTotal(totalVenta);
        nuevaVenta.setEstado("PENDIENTE");
        nuevaVenta.setFechaVenta(LocalDateTime.now());
        Venta ventaGuardada = ventaRepository.save(nuevaVenta);

        // Guardar detalles y limpiar carrito
        for (int i = 0; i < itemsCarrito.size(); i++) {
            CarritoDTO item = itemsCarrito.get(i);
            ProductoDTO producto = productosResueltos.get(i);

            VentaDetalle detalle = new VentaDetalle();
            detalle.setVentaId(ventaGuardada.getId());
            detalle.setProductoId(item.getProductoId());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(producto.getPrecio());
            detalleRepository.save(detalle);

            carritoClient.eliminarItem(item.getId());
        }

        return ventaGuardada;
    }

    public Venta actualizarEstado(Long id, String nuevoEstado) {
        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Venta no encontrada con ID: " + id));

        venta.setEstado(nuevoEstado);
        Venta ventaActualizada = ventaRepository.save(venta);

        if ("ENTREGADO".equals(nuevoEstado)) {
            List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
            for (VentaDetalle detalle : detalles) {
                try {
                    Map<String, Object> data = Map.of(
                            "usuarioId", venta.getUsuarioId(),
                            "productoId", detalle.getProductoId());
                    resenaClient.habilitarResena(data);
                } catch (Exception e) {
                    System.err.println("No se pudo habilitar reseña: " + e.getMessage());
                }
            }
        }

        if ("PAGADO".equals(nuevoEstado)) {
            List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
            for (VentaDetalle detalle : detalles) {
                productoClient.descontarStock(detalle.getProductoId(), detalle.getCantidad());
            }

            try {
                UsuarioDTO usuario = usuarioClient.obtenerPorId(venta.getUsuarioId());

                EnvioDTO nuevoEnvio = new EnvioDTO();
                nuevoEnvio.setVentaId(venta.getId());
                nuevoEnvio.setDireccionEntrega(
                        usuario.getDireccion() != null ? usuario.getDireccion() : "Dirección Pendiente");

                envioClient.crearEnvio(nuevoEnvio);
            } catch (Exception e) {
                System.err.println("Advertencia: No se pudo generar el envío automático para la venta "
                        + id + ". Detalle: " + e.getMessage());
            }
        }

        return ventaActualizada;
    }

    public void eliminar(Long id) {
        ventaRepository.deleteById(id);
    }
}