package te.ventas.dto;

import lombok.Data;

@Data
public class CheckoutRequest {
    private Long usuarioId;
    private String codigoCupon;
}