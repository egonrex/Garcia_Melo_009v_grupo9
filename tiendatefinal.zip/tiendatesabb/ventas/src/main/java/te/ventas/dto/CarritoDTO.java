package te.ventas.dto;
import lombok.Data;

@Data
public class CarritoDTO {
    private Long id;
    private Long usuarioId;
    private Long productoId;
    private int cantidad;
}