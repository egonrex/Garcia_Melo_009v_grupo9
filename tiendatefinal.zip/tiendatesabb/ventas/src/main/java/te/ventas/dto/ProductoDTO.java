package te.ventas.dto;

import lombok.Data;

@Data
public class ProductoDTO {
    private Long id;
    private Integer precio;
    private Integer stock;
}
