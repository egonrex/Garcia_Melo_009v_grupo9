package te.ventas.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "venta_detalles")
@Data // Lombok nos ahorra los getters y setters
public class VentaDetalle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long ventaId;

    @Column(nullable = false)
    private Long productoId;

    @Column(nullable = false)
    private Integer cantidad;

    @Column(nullable = false)
    private Integer precioUnitario;
}