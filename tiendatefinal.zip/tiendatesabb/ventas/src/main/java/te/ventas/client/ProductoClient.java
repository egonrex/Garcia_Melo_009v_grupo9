package te.ventas.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import te.ventas.dto.ProductoDTO;

@FeignClient(name = "principal")
public interface ProductoClient {

    @GetMapping("/api/productos/{id}")
    ProductoDTO obtenerPorId(@PathVariable("id") Long id);

    // Nuevo método para descontar stock
    @PutMapping("/api/productos/{id}/descontar-stock")
    void descontarStock(@PathVariable("id") Long id, @RequestParam("cantidad") Integer cantidad);
}