package te.ventas.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import feign.FeignException;
import te.ventas.client.CarritoClient;
import te.ventas.client.CuponClient;
import te.ventas.client.EnvioClient;
import te.ventas.client.ProductoClient;
import te.ventas.client.ResenaClient;
import te.ventas.client.UsuarioClient;
import te.ventas.dto.CarritoDTO;
import te.ventas.dto.CheckoutRequest;
import te.ventas.dto.CuponDTO;
import te.ventas.dto.ProductoDTO;
import te.ventas.model.Venta;
import te.ventas.model.VentaDetalle;
import te.ventas.repository.VentaDetalleRepository;
import te.ventas.repository.VentaRepository;
import te.ventas.service.VentaService;

@ExtendWith(MockitoExtension.class)
public class VentaServiceTest {

    @InjectMocks
    private VentaService ventaService;

    @Mock
    private VentaRepository ventaRepository;

    @Mock
    private VentaDetalleRepository detalleRepository;

    @Mock
    private CarritoClient carritoClient;

    @Mock
    private ProductoClient productoClient;

    @Mock
    private CuponClient cuponClient;

    @Mock
    private UsuarioClient usuarioClient;

    @Mock
    private EnvioClient envioClient;

    @Mock
    private ResenaClient resenaClient;

    @Test
    void procesarCheckout_CasoFeliz() {
        // --- ARRANGE (Preparar) ---
        CheckoutRequest request = new CheckoutRequest();
        request.setUsuarioId(1L);
        request.setCodigoCupon("DESCUENTO10");

        CarritoDTO item = new CarritoDTO();
        item.setId(100L);
        item.setProductoId(10L);
        item.setCantidad(2);

        ProductoDTO producto = new ProductoDTO();
        producto.setId(10L);
        producto.setPrecio(5000);
        producto.setStock(10); // Stock suficiente (10 > 2)

        CuponDTO cupon = new CuponDTO();
        // cupon.setCodigo("DESCUENTO10");
        cupon.setActivo(true);
        cupon.setPorcentaje(10);

        Venta ventaGuardadaMock = new Venta();
        ventaGuardadaMock.setId(1L);
        ventaGuardadaMock.setTotal(9000); // (5000 * 2) = 10000 - 10% = 9000

        when(carritoClient.obtenerPorUsuario(1L)).thenReturn(List.of(item));
        when(productoClient.obtenerPorId(10L)).thenReturn(producto);
        when(cuponClient.obtenerPorCodigo("DESCUENTO10")).thenReturn(cupon);
        when(ventaRepository.save(any(Venta.class))).thenReturn(ventaGuardadaMock);

        // --- ACT (Actuar) ---
        Venta resultado = ventaService.procesarCheckout(request);

        // --- ASSERT (Afirmar) ---
        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        
        // Verificamos que se guardó el detalle y se limpió el carrito
        verify(detalleRepository, times(1)).save(any(VentaDetalle.class));
        verify(carritoClient, times(1)).eliminarItem(100L);
    }

    @Test
    void procesarCheckout_ErrorCarritoVacio() {
        // --- ARRANGE ---
        CheckoutRequest request = new CheckoutRequest();
        request.setUsuarioId(1L);

        when(carritoClient.obtenerPorUsuario(1L)).thenReturn(Collections.emptyList());

        // --- ACT & ASSERT ---
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            ventaService.procesarCheckout(request);
        });

        assertEquals("El carrito está vacío. No se puede procesar la venta.", exception.getMessage());
        verifyNoInteractions(productoClient, ventaRepository);
    }

    @Test
    void procesarCheckout_ErrorProductoNoExiste() {
        // --- ARRANGE ---
        CheckoutRequest request = new CheckoutRequest();
        request.setUsuarioId(1L);

        CarritoDTO item = new CarritoDTO();
        item.setProductoId(99L); // ID inexistente
        
        when(carritoClient.obtenerPorUsuario(1L)).thenReturn(List.of(item));
        
        // Simulamos el 404 de Feign
        FeignException.NotFound notFoundException = mock(FeignException.NotFound.class);
        when(productoClient.obtenerPorId(99L)).thenThrow(notFoundException);

        // --- ACT & ASSERT ---
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            ventaService.procesarCheckout(request);
        });

        assertTrue(exception.getMessage().contains("ya no existe."));
        verifyNoInteractions(ventaRepository);
    }

    @Test
    void procesarCheckout_ErrorStockInsuficiente() {
        // --- ARRANGE ---
        CheckoutRequest request = new CheckoutRequest();
        request.setUsuarioId(1L);

        CarritoDTO item = new CarritoDTO();
        item.setProductoId(10L);
        item.setCantidad(5); // Pide 5

        ProductoDTO producto = new ProductoDTO();
        producto.setId(10L);
        producto.setStock(2); // Solo hay 2 en stock

        when(carritoClient.obtenerPorUsuario(1L)).thenReturn(List.of(item));
        when(productoClient.obtenerPorId(10L)).thenReturn(producto);

        // --- ACT & ASSERT ---
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            ventaService.procesarCheckout(request);
        });

        assertTrue(exception.getMessage().contains("No hay stock suficiente."));
        verifyNoInteractions(ventaRepository);
    }

    @Test
    void procesarCheckout_ErrorCuponInvalidoOInactivo() {
        // --- ARRANGE ---
        CheckoutRequest request = new CheckoutRequest();
        request.setUsuarioId(1L);
        request.setCodigoCupon("FALSO");

        CarritoDTO item = new CarritoDTO();
        item.setProductoId(10L);
        item.setCantidad(1);

        ProductoDTO producto = new ProductoDTO();
        producto.setStock(10);
        producto.setPrecio(1000);

        CuponDTO cuponFalso = new CuponDTO();
        cuponFalso.setActivo(false); // Inactivo

        when(carritoClient.obtenerPorUsuario(1L)).thenReturn(List.of(item));
        when(productoClient.obtenerPorId(10L)).thenReturn(producto);
        when(cuponClient.obtenerPorCodigo("FALSO")).thenReturn(cuponFalso);

        // --- ACT & ASSERT ---
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            ventaService.procesarCheckout(request);
        });

        assertEquals("El cupón no es válido o ya expiró", exception.getMessage());
        verifyNoInteractions(ventaRepository);
    }

    @Test
    void procesarCheckout_ErrorCuponNoEncontradoFeign() {
        // --- ARRANGE ---
        CheckoutRequest request = new CheckoutRequest();
        request.setUsuarioId(1L);
        request.setCodigoCupon("NO_EXISTE");

        CarritoDTO item = new CarritoDTO();
        item.setProductoId(10L);
        item.setCantidad(1);

        ProductoDTO producto = new ProductoDTO();
        producto.setStock(10);
        producto.setPrecio(1000);

        when(carritoClient.obtenerPorUsuario(1L)).thenReturn(List.of(item));
        when(productoClient.obtenerPorId(10L)).thenReturn(producto);

        FeignException.NotFound notFoundException = mock(FeignException.NotFound.class);
        when(cuponClient.obtenerPorCodigo("NO_EXISTE")).thenThrow(notFoundException);

        // --- ACT & ASSERT ---
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            ventaService.procesarCheckout(request);
        });

        assertEquals("El cupón no es válido o ya expiró", exception.getMessage());
        verifyNoInteractions(ventaRepository);
    }

    @Test
    void procesarCheckout_ErrorGenericoCupon() {
        // --- ARRANGE ---
        CheckoutRequest request = new CheckoutRequest();
        request.setUsuarioId(1L);
        request.setCodigoCupon("ERROR_GENERICO");

        CarritoDTO item = new CarritoDTO();
        item.setProductoId(10L);
        item.setCantidad(1);

        ProductoDTO producto = new ProductoDTO();
        producto.setStock(10);
        producto.setPrecio(1000);

        when(carritoClient.obtenerPorUsuario(1L)).thenReturn(List.of(item));
        when(productoClient.obtenerPorId(10L)).thenReturn(producto);
        
        // Simulamos una caída del servidor (Timeout, 500, etc)
        when(cuponClient.obtenerPorCodigo("ERROR_GENERICO")).thenThrow(new RuntimeException("Servicio caído"));

        // --- ACT & ASSERT ---
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            ventaService.procesarCheckout(request);
        });

        assertEquals("Error al validar el cupón. Intente nuevamente.", exception.getMessage());
        verifyNoInteractions(ventaRepository);
    }
}