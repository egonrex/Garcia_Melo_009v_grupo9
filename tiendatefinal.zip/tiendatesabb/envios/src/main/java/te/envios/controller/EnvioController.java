package te.envios.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import te.envios.model.Envio;
import te.envios.service.EnvioService;
import te.envios.client.SucursalClient; // <-- NUEVA IMPORTACIÓN

@RestController
@RequestMapping("/api/envios")
public class EnvioController {

    @Autowired
    private EnvioService envioService;

    @Autowired
    private SucursalClient sucursalClient; // <-- INYECCIÓN DEL CLIENTE FEIGN

    @GetMapping
    public List<Envio> obtenerTodos() {
        return envioService.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Envio> obtenerPorId(@PathVariable Long id) {
        return envioService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/venta/{ventaId}")
    public ResponseEntity<Envio> obtenerPorVenta(@PathVariable Long ventaId) {
        return envioService.buscarPorVentaId(ventaId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Envio envio) {
        
        // 1. Asignar un valor por defecto si viene nulo para no romper la creación automática desde Ventas
        if (envio.getTipoEnvio() == null) {
            envio.setTipoEnvio("DOMICILIO");
        }

        // 2. Regla con IF: Validar si es RETIRO
        if ("RETIRO".equalsIgnoreCase(envio.getTipoEnvio())) {
            
            // Si es retiro, debe venir con la sucursal indicada
            if (envio.getSucursalId() == null) {
                return ResponseEntity.badRequest().body("Error: Para envíos tipo RETIRO debe indicar un sucursalId.");
            }

            // Buscar en microservicio Sucursales
            try {
                sucursalClient.obtenerPorId(envio.getSucursalId());
            } catch (feign.FeignException.NotFound e) {
                // Si no existe, devolver error
                return ResponseEntity.badRequest().body("Error: La sucursal indicada no existe.");
            } catch (Exception e) {
                return ResponseEntity.internalServerError().body("Error de comunicación con el servicio de Sucursales.");
            }
        }

        // 3. Guardar el envío
        Envio nuevoEnvio = envioService.crearEnvio(envio);
        return ResponseEntity.ok(nuevoEnvio);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (envioService.buscarPorId(id).isPresent()) {
            envioService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}