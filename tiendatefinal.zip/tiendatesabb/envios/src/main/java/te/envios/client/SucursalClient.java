package te.envios.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import te.envios.dto.SucursalDTO;

@FeignClient(name = "sucursales") // Apunta al microservicio de sucursales
public interface SucursalClient {

    @GetMapping("/api/sucursales/{id}")
    SucursalDTO obtenerPorId(@PathVariable("id") Long id);
}