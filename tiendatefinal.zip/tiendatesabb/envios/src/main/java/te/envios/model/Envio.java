package te.envios.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "envios")
public class Envio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long ventaId;

    @Column(nullable = false, length = 255)
    private String direccionEntrega;

    @Column(length = 50)
    private String estado; // Ej: PREPARANDO, EN_RATA, ENTREGADO

    @Column(length = 100)
    private String numeroSeguimiento; // Código del courier (Bluexpress, Starken, etc.)

    @Column(length = 20)
    private String tipoEnvio;

    @Column(nullable = true)
    private Long sucursalId;


    // Constructores
    public Envio() {}

    public Envio(Long id, Long ventaId, String direccionEntrega, String estado, String numeroSeguimiento) {
        this.id = id;
        this.ventaId = ventaId;
        this.direccionEntrega = direccionEntrega;
        this.estado = estado;
        this.numeroSeguimiento = numeroSeguimiento;
        this.tipoEnvio = tipoEnvio;
        this.sucursalId = sucursalId;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getVentaId() { return ventaId; }
    public void setVentaId(Long ventaId) { this.ventaId = ventaId; }

    public String getDireccionEntrega() { return direccionEntrega; }
    public void setDireccionEntrega(String direccionEntrega) { this.direccionEntrega = direccionEntrega; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getNumeroSeguimiento() { return numeroSeguimiento; }
    public void setNumeroSeguimiento(String numeroSeguimiento) { this.numeroSeguimiento = numeroSeguimiento; }

    public String getTipoEnvio() { return tipoEnvio; }
    public void setTipoEnvio(String tipoEnvio) { this.tipoEnvio = tipoEnvio; }

    public Long getSucursalId() { return sucursalId; }
    public void setSucursalId(Long sucursalId) { this.sucursalId = sucursalId; }
}