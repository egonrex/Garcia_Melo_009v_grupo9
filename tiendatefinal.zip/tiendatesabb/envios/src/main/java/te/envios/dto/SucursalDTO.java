package te.envios.dto;

import lombok.Data;

@Data
public class SucursalDTO {
    private Long id;
    private String nombre;
}