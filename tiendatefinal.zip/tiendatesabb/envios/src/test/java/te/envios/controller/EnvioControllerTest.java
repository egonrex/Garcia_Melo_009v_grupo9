package te.envios.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import feign.FeignException;
import te.envios.client.SucursalClient;
import te.envios.dto.SucursalDTO;
import te.envios.model.Envio;
import te.envios.service.EnvioService;

@ExtendWith(MockitoExtension.class)
public class EnvioControllerTest {

    @InjectMocks
    private EnvioController envioController;

    @Mock
    private EnvioService envioService;

    @Mock
    private SucursalClient sucursalClient;

    @Test
    void crearEnvio_CasoFeliz_Domicilio() {
        // --- ARRANGE (Preparar) ---
        Envio envioRequest = new Envio();
        envioRequest.setVentaId(1L);
        envioRequest.setDireccionEntrega("Av. Pajaritos 1234");
        envioRequest.setTipoEnvio("DOMICILIO");
        
        Envio envioGuardado = new Envio();
        envioGuardado.setId(10L);
        envioGuardado.setTipoEnvio("DOMICILIO");
        envioGuardado.setEstado("PREPARANDO");

        when(envioService.crearEnvio(any(Envio.class))).thenReturn(envioGuardado);

        // --- ACT (Actuar) ---
        ResponseEntity<?> response = envioController.crear(envioRequest);

        // --- ASSERT (Afirmar) ---
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        
        // Verificamos que para envío a domicilio NO se llamó al microservicio de Sucursales
        verifyNoInteractions(sucursalClient);
        verify(envioService, times(1)).crearEnvio(envioRequest);
    }

    @Test
    void crearEnvio_CasoFeliz_RetiroEnSucursal() {
        // --- ARRANGE ---
        Envio envioRequest = new Envio();
        envioRequest.setVentaId(2L);
        envioRequest.setTipoEnvio("RETIRO");
        envioRequest.setSucursalId(5L); // Sucursal asignada
        
        SucursalDTO sucursalMock = new SucursalDTO();
        
        Envio envioGuardado = new Envio();
        envioGuardado.setId(11L);

        // Simulamos que la sucursal existe
        when(sucursalClient.obtenerPorId(5L)).thenReturn(sucursalMock);
        when(envioService.crearEnvio(any(Envio.class))).thenReturn(envioGuardado);

        // --- ACT ---
        ResponseEntity<?> response = envioController.crear(envioRequest);

        // --- ASSERT ---
        assertEquals(HttpStatus.OK, response.getStatusCode());
        
        // Verificamos que SÍ se consultó a la sucursal antes de guardar
        verify(sucursalClient, times(1)).obtenerPorId(5L);
        verify(envioService, times(1)).crearEnvio(envioRequest);
    }

    @Test
    void crearEnvio_Error_RetiroSinSucursalId() {
        // --- ARRANGE ---
        Envio envioRequest = new Envio();
        envioRequest.setVentaId(3L);
        envioRequest.setTipoEnvio("RETIRO");
        envioRequest.setSucursalId(null); // Olvidó enviar la sucursal

        // --- ACT ---
        ResponseEntity<?> response = envioController.crear(envioRequest);

        // --- ASSERT ---
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Error: Para envíos tipo RETIRO debe indicar un sucursalId.", response.getBody());
        
        // Verificamos que el proceso se detuvo a tiempo
        verifyNoInteractions(sucursalClient, envioService);
    }

    @Test
    void crearEnvio_Error_RetiroSucursalNoExiste() {
        // --- ARRANGE ---
        Envio envioRequest = new Envio();
        envioRequest.setVentaId(4L);
        envioRequest.setTipoEnvio("RETIRO");
        envioRequest.setSucursalId(99L); // Sucursal inventada

        // Simulamos que el microservicio Sucursales responde con un 404 (No existe)
        FeignException.NotFound notFoundException = mock(FeignException.NotFound.class);
        when(sucursalClient.obtenerPorId(99L)).thenThrow(notFoundException);

        // --- ACT ---
        ResponseEntity<?> response = envioController.crear(envioRequest);

        // --- ASSERT ---
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Error: La sucursal indicada no existe.", response.getBody());
        
        // Verificamos que la validación detuvo el proceso y NO se guardó el envío
        verify(sucursalClient, times(1)).obtenerPorId(99L);
        verifyNoInteractions(envioService);
    }
}