# Proyecto Tienda Té

##  Repositorio del Proyecto
* **GitHub Repository:** [https://github.com/egonrex/Garcia_Melo_009v_grupo9/blob/main/TiendaTe1.zip](https://github.com/egonrex/Garcia_Melo_009v_grupo9/blob/main/TiendaTe1.zip)

## 1. Descripción del Proyecto
Este proyecto es una implementación de arquitectura basada en microservicios diseñada para gestionar la operativa completa de una tienda de venta de tés y accesorios. El sistema simula el flujo transaccional real, abarcando desde la consulta de catálogo y control estricto de inventario, hasta el procesamiento de pagos, aplicación de descuentos y orquestación logística de envíos y retiros en tienda.

## 2. Nombre de Integrantes
* Gerald Garcia
* Egon Melo

## 3 APIs y Endpoints Disponibles

A continuación se detallan los endpoints expuestos por cada microservicio. (Nota: Si se ejecuta mediante Docker local, los servicios están mapeados del puerto `8081` al `8090`).

### API de Ventas (`ventas` - Puerto 8082)
* `POST /api/ventas/checkout` - Procesar una nueva compra (Evalúa stock y cupones)
* `GET /api/ventas` - Obtener todas las ventas registradas
* `GET /api/ventas/{id}` - Obtener el detalle de una venta por su ID
* `GET /api/ventas/usuario/{usuarioId}` - Obtener el historial de compras de un cliente
* `PUT /api/ventas/{id}/estado?estado={estado}` - Actualizar el estado de la venta (Ej: PAGADO, ENTREGADO)
* `POST /api/ventas` - Crear una venta de forma manual (Uso administrativo)
* `DELETE /api/ventas/{id}` - Eliminar un registro de venta

### API de Catálogo / Productos (`principal` - Puerto 8081)
* `POST /api/productos` - Crear un nuevo producto en el inventario
* `GET /api/productos` - Obtener todos los productos del catálogo
* `GET /api/productos/{id}` - Obtener un producto específico por su ID
* `GET /api/productos/categoria/{categoria}` - Filtrar productos por categoría (Ej: Té Verde)
* `PUT /api/productos/{id}/descontar-stock?cantidad={cantidad}` - Descontar unidades del inventario
* `DELETE /api/productos/{id}` - Eliminar un producto

### API de Carrito de Compras (`carrito` - Puerto 8084)
* `POST /api/carrito` - Agregar un nuevo ítem al carrito de un usuario
* `GET /api/carrito` - Obtener todos los ítems en carritos activos
* `GET /api/carrito/usuario/{usuarioId}` - Obtener los ítems en el carrito de un usuario específico
* `DELETE /api/carrito/{id}` - Eliminar un ítem del carrito

### API de Pagos (`pagos` - Puerto 8085)
* `POST /api/pagos` - Registrar y procesar el pago de una orden
* `GET /api/pagos` - Obtener el historial de transacciones financieras
* `GET /api/pagos/{id}` - Obtener un comprobante de pago por su ID

### API de Logística y Envíos (`envios` - Puerto 8086)
* `POST /api/envios` - Crear una nueva orden de despacho (Soporta tipo DOMICILIO o RETIRO)
* `GET /api/envios` - Obtener todos los envíos
* `GET /api/envios/{id}` - Obtener el detalle logístico por ID de envío
* `GET /api/envios/venta/{ventaId}` - Consultar el estado de despacho de una compra
* `DELETE /api/envios/{id}` - Eliminar una orden de envío

### API de Usuarios (`usuarios` - Puerto 8083)
* `POST /api/usuarios` - Registrar un nuevo cliente
* `GET /api/usuarios` - Obtener el listado de todos los clientes
* `GET /api/usuarios/{id}` - Obtener el perfil y dirección de un cliente por su ID
* `DELETE /api/usuarios/{id}` - Dar de baja a un usuario

### API de Cupones de Descuento (`cupones` - Puerto 8087)
* `POST /api/cupones` - Crear una nueva regla de promoción/cupón
* `GET /api/cupones` - Obtener todos los cupones registrados
* `GET /api/cupones/codigo/{codigo}` - Validar y obtener detalles de un cupón específico
* `DELETE /api/cupones/{id}` - Eliminar un cupón

### API de Sucursales (`sucursales` - Puerto 8090)
* `POST /api/sucursales` - Registrar una nueva tienda física
* `GET /api/sucursales` - Listar todas las tiendas disponibles
* `GET /api/sucursales/{id}` - Obtener información de un local (horarios y ubicación) por ID
* `DELETE /api/sucursales/{id}` - Eliminar el registro de una sucursal

### API de Proveedores (`proovedores` - Puerto 8089)
* `POST /api/proveedores` - Ingresar un nuevo proveedor o importador
* `GET /api/proveedores` - Obtener la lista de abastecedores
* `GET /api/proveedores/{id}` - Obtener los datos de contacto de un proveedor por ID
* `DELETE /api/proveedores/{id}` - Eliminar un proveedor

### API de Reseñas de Productos (`resenas` - Puerto 8088)
* `POST /api/resenas` - Dejar un comentario y calificación sobre un producto
* `GET /api/resenas` - Listar todos los comentarios del sistema
* `GET /api/resenas/{id}` - Obtener una reseña específica por ID
* `GET /api/resenas/producto/{productoId}` - Listar todas las opiniones de un producto específico
* `DELETE /api/resenas/{id}` - Eliminar una reseña (Moderación)



## 6. Enlaces de Swagger (Documentación Local)

Para revisar y probar los contratos de las APIs de manera interactiva y aislada por microservicio (asegúrate de que los contenedores estén en ejecución):

* **Microservicio Catálogo (Principal):** [http://localhost:8081/doc/swagger-ui/index.html](http://localhost:8081/doc/swagger-ui/index.html)
* **Microservicio Ventas:** [http://localhost:8082/doc/swagger-ui/index.html](http://localhost:8082/doc/swagger-ui/index.html)
* **Microservicio Usuarios:** [http://localhost:8083/doc/swagger-ui/index.html](http://localhost:8083/doc/swagger-ui/index.html)
* **Microservicio Carrito:** [http://localhost:8084/doc/swagger-ui/index.html](http://localhost:8084/doc/swagger-ui/index.html)
* **Microservicio Pagos:** [http://localhost:8085/doc/swagger-ui/index.html](http://localhost:8085/doc/swagger-ui/index.html)
* **Microservicio Envíos:** [http://localhost:8086/doc/swagger-ui/index.html](http://localhost:8086/doc/swagger-ui/index.html)
* **Microservicio Cupones:** [http://localhost:8087/doc/swagger-ui/index.html](http://localhost:8087/doc/swagger-ui/index.html)
* **Microservicio Reseñas:** [http://localhost:8088/doc/swagger-ui/index.html](http://localhost:8088/doc/swagger-ui/index.html)
* **Microservicio Proveedores:** [http://localhost:8089/doc/swagger-ui/index.html](http://localhost:8089/doc/swagger-ui/index.html)
* **Microservicio Sucursales:** [http://localhost:8090/doc/swagger-ui/index.html](http://localhost:8090/doc/swagger-ui/index.html)




## 🛒 7. Guía de Uso paso a paso (Flujo de Compra en Postman)

Dado que este proyecto es una arquitectura Backend pura, la interacción se realiza mediante clientes REST como Postman o Insomnia. A continuación, se detalla el "Happy Path" (Camino Feliz) para simular la compra de un té y ver cómo los microservicios interactúan en cadena.

*(Asegúrate de que todos los servicios y bases de datos estén corriendo vía Docker Compose y que Eureka registre las instancias).*

### Paso 1: Preparar el Catálogo y el Cliente (Setup inicial)
Si la base de datos está vacía, primero necesitamos un producto y un cliente.

1. **Crear un Producto (Microservicio Principal - Puerto 8081):**
   * **Endpoint:** `POST http://localhost:8081/api/productos`
   * **Body (JSON):**
     ```json
     {
       "nombre": "Té Verde Matcha Orgánico",
       "categoria": "Té Verde",
       "precio": 15000,
       "stock": 50
     }
     ```

2. **Crear un Usuario (Microservicio Usuarios - Puerto 8083):**
   * **Endpoint:** `POST http://localhost:8083/api/usuarios`
   * **Body (JSON):**
     ```json
     {
       "nombre": "Juan Pérez",
       "email": "juan.perez@email.com",
       "direccion": "Av. Los Pajaritos 1234, Maipú"
     }
     ```

### Paso 2: Agregar productos al Carrito
Simulamos que el usuario navega por la tienda y añade el Té Matcha a su carro de compras.

* **Endpoint (Microservicio Carrito - Puerto 8084):** `POST http://localhost:8084/api/carrito`
* **Body (JSON):**
  ```json
  {
    "usuarioId": 1,
    "productoId": 1,
    "cantidad": 2
  }
Paso 3: Realizar el Checkout (El Orquestador en Acción)
Aquí es donde brilla la arquitectura. Le pedimos a Ventas que consolide la compra. Ventas se comunicará por debajo con Carrito, Principal (Productos) y Cupones.

Endpoint (Microservicio Ventas - Puerto 8082): POST http://localhost:8082/api/ventas/checkout

Body (JSON):

JSON
{
  "usuarioId": 1,
  "metodoPago": "TARJETA_CREDITO"
}
Resultado esperado: Se creará una Venta en estado PENDIENTE. El sistema debe haber vaciado el carrito automáticamente y reservado el stock. Anota el ID de la Venta generada.

Paso 4: Procesar el Pago
Simulamos que la pasarela bancaria aprobó la transacción.

Endpoint (Microservicio Pagos - Puerto 8085): POST http://localhost:8085/api/pagos

Body (JSON):

JSON
{
  "ventaId": 1,
  "montoPagado": 30000,
  "metodoPago": "TARJETA_CREDITO",
  "estado": "APROBADO"
}
Resultado esperado: El microservicio de Pagos le avisará internamente al de Ventas que el pago fue exitoso. La venta pasará a estado PAGADO.

Paso 5: Verificación de la Logística
Como la venta ya está pagada, el sistema debió disparar automáticamente la orden de despacho a la dirección del cliente.

Endpoint (Microservicio Envíos - Puerto 8086): GET http://localhost:8086/api/envios/venta/1

Resultado esperado: Verás un JSON indicando que el envío va dirigido a "Av. Los Pajaritos 1234, Maipú" y que su estado actual es PREPARANDO.