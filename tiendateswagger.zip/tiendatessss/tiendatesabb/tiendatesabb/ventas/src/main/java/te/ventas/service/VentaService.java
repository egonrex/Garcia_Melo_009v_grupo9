package te.ventas.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.ventas.client.CarritoClient;
import te.ventas.client.CuponClient;
import te.ventas.client.EnvioClient;
import te.ventas.client.ProductoClient;
import te.ventas.client.ResenaClient;
import te.ventas.client.UsuarioClient;
import te.ventas.dto.CarritoDTO;
import te.ventas.dto.CheckoutRequest;
import te.ventas.dto.CuponDTO;
import te.ventas.dto.EnvioDTO;
import te.ventas.dto.ProductoDTO;
import te.ventas.dto.UsuarioDTO;
import te.ventas.model.Venta;
import te.ventas.model.VentaDetalle;
import te.ventas.repository.VentaDetalleRepository;
import te.ventas.repository.VentaRepository;

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private VentaDetalleRepository detalleRepository;

    @Autowired
    private CarritoClient carritoClient;

    @Autowired
    private ProductoClient productoClient;

    @Autowired
    private CuponClient cuponClient;

    @Autowired
    private UsuarioClient usuarioClient;

    @Autowired
    private EnvioClient envioClient;

    @Autowired
    private ResenaClient resenaClient;

    public List<Venta> listarTodas() {
        return ventaRepository.findAll();
    }

    public Optional<Venta> buscarPorId(Long id) {
        return ventaRepository.findById(id);
    }

    public List<Venta> historialPorUsuario(Long usuarioId) {
        return ventaRepository.findByUsuarioId(usuarioId);
    }

    public Venta crearVenta(Venta venta) {
        if (venta.getFechaVenta() == null) {
            venta.setFechaVenta(LocalDateTime.now());
        }
        if (venta.getEstado() == null || venta.getEstado().isEmpty()) {
            venta.setEstado("PENDIENTE");
        }
        return ventaRepository.save(venta);
    }

    public Venta procesarCheckout(CheckoutRequest request) {
        List<CarritoDTO> itemsCarrito = carritoClient.obtenerPorUsuario(request.getUsuarioId());

        if (itemsCarrito == null || itemsCarrito.isEmpty()) {
            throw new IllegalStateException("El carrito está vacío. No se puede procesar la venta.");
        }

        // FIX 1: Guardamos los productos resueltos en la primera pasada para no
        // llamar dos veces a Feign por el mismo ítem (evita doble consulta y
        // posibles inconsistencias de stock entre ambas llamadas).
        List<ProductoDTO> productosResueltos = new ArrayList<>();

        int totalVenta = 0;
        for (CarritoDTO item : itemsCarrito) {
            ProductoDTO producto;
            try {
                producto = productoClient.obtenerPorId(item.getProductoId());
            } catch (feign.FeignException.NotFound e) {
                throw new IllegalStateException(
                        "Error: El producto con ID " + item.getProductoId() + " que está en el carrito ya no existe.");
            }

            if (producto.getStock() < item.getCantidad()) {
                throw new IllegalStateException("Stock insuficiente para el producto ID: " + item.getProductoId());
            }

            totalVenta += (producto.getPrecio() * item.getCantidad());
            productosResueltos.add(producto); // guardamos para la segunda pasada
        }

        // FIX 2: Aplicar cupón correctamente.
        // Antes: cuponClient lanzaba FeignException 404 cuando el código no existía
        // y ese error no estaba capturado, reventando el checkout.
        // Ahora: envolvemos la llamada en try-catch para manejar cupones inexistentes
        // sin interrumpir el flujo, tal como hace la lógica de envíos/reseñas.
        if (request.getCodigoCupon() != null && !request.getCodigoCupon().trim().isEmpty()) {
            try {
                CuponDTO cupon = cuponClient.obtenerPorCodigo(request.getCodigoCupon());
                if (cupon != null && Boolean.TRUE.equals(cupon.getActivo())) {
                    totalVenta -= (totalVenta * cupon.getPorcentaje()) / 100;
                }
            } catch (feign.FeignException.NotFound e) {
                // El código de cupón no existe: simplemente ignoramos el descuento.
                System.err.println("Advertencia: Cupón '" + request.getCodigoCupon() + "' no encontrado. Se ignora el descuento.");
            }
        }

        // Guardamos la venta cabecera
        Venta nuevaVenta = new Venta();
        nuevaVenta.setUsuarioId(request.getUsuarioId());
        nuevaVenta.setTotal(totalVenta);
        nuevaVenta.setEstado("PENDIENTE");
        nuevaVenta.setFechaVenta(LocalDateTime.now());
        Venta ventaGuardada = ventaRepository.save(nuevaVenta);

        // FIX 3: Usamos los productos ya resueltos (productosResueltos) en lugar de
        // volver a llamar a productoClient.obtenerPorId() dentro del bucle.
        // Esto elimina la segunda ronda de llamadas Feign que existía en el código
        // original y que podía devolver datos distintos si el stock cambiaba entre
        // ambas peticiones.
        for (int i = 0; i < itemsCarrito.size(); i++) {
            CarritoDTO item = itemsCarrito.get(i);
            ProductoDTO producto = productosResueltos.get(i);

            VentaDetalle detalle = new VentaDetalle();
            detalle.setVentaId(ventaGuardada.getId());
            detalle.setProductoId(item.getProductoId());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(producto.getPrecio());
            detalleRepository.save(detalle);

            carritoClient.eliminarItem(item.getId());
        }

        return ventaGuardada;
    }

    public Venta actualizarEstado(Long id, String nuevoEstado) {
        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Venta no encontrada con ID: " + id));

        venta.setEstado(nuevoEstado);
        Venta ventaActualizada = ventaRepository.save(venta);

        if ("ENTREGADO".equals(nuevoEstado)) {
            List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
            for (VentaDetalle detalle : detalles) {
                try {
                    Map<String, Object> data = Map.of(
                            "usuarioId", venta.getUsuarioId(),
                            "productoId", detalle.getProductoId());
                    resenaClient.habilitarResena(data);
                } catch (Exception e) {
                    System.err.println("No se pudo habilitar reseña: " + e.getMessage());
                }
            }
        }

        if ("PAGADO".equals(nuevoEstado)) {
            List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
            for (VentaDetalle detalle : detalles) {
                productoClient.descontarStock(detalle.getProductoId(), detalle.getCantidad());
            }

            try {
                UsuarioDTO usuario = usuarioClient.obtenerPorId(venta.getUsuarioId());

                EnvioDTO nuevoEnvio = new EnvioDTO();
                nuevoEnvio.setVentaId(venta.getId());
                nuevoEnvio.setDireccionEntrega(
                        usuario.getDireccion() != null ? usuario.getDireccion() : "Dirección Pendiente");

                envioClient.crearEnvio(nuevoEnvio);
            } catch (Exception e) {
                System.err.println("Advertencia: No se pudo generar el envío automático para la venta "
                        + id + ". Detalle: " + e.getMessage());
            }
        }

        return ventaActualizada;
    }

    public void eliminar(Long id) {
        ventaRepository.deleteById(id);
    }
}