package te.principal.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor 
@AllArgsConstructor
@Data
@Entity
@Table(name = "productos")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre; // Ej: Té Negro Ceylan, Tetera de Hierro

    @Column(length = 255)
    private String descripcion;

    @Column(nullable = false)
    private Integer precio; 

    @Column(nullable = false)
    private Integer stock;

    @Column(length = 50)
    private String categoria; // Ej: Te Verde, Te Negro, Accesorios

    // --- NUEVA COLUMNA ---
    @Column(nullable = false)
    private Long proveedorId;

}