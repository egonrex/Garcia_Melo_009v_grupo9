package te.principal.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "proveedores") 
public interface ProveedorClient {

    // Al cambiar a 'void', le decimos a Feign: "No intentes convertir nada a objeto"
    // Feign lanzará automáticamente una FeignException si el código es 404.
    @GetMapping("/api/proveedores/{id}")
    void obtenerPorId(@PathVariable("id") Long id); 
}