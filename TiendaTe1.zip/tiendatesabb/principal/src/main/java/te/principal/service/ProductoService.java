package te.principal.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.principal.client.ProveedorClient;
import te.principal.model.Producto;
import te.principal.repository.ProductoRepository;

@Service
public class ProductoService {

    // 1. Inyección de dependencias siempre al principio
    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private ProveedorClient proveedorClient;

    // 2. Métodos estándar (CRUD)
    public List<Producto> listarTodos() {
        return productoRepository.findAll();
    }

    public Optional<Producto> buscarPorId(Long id) {
        return productoRepository.findById(id);
    }

    public List<Producto> buscarPorCategoria(String categoria) {
        return productoRepository.findByCategoria(categoria);
    }

    public Producto guardar(Producto producto) {
        return productoRepository.save(producto);
    }

    public void eliminar(Long id) {
        productoRepository.deleteById(id);
    }
    
    public Optional<Producto> buscarPorNombre(String nombre) {
        return productoRepository.findByNombre(nombre);
    }

    // 3. Reglas de negocio específicas (Custom)
    public Producto descontarStock(Long id, Integer cantidad) {
        Producto producto = productoRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado"));
        
        if (producto.getStock() < cantidad) {
            throw new IllegalStateException("Stock insuficiente para el producto: " + producto.getNombre());
        }
        
        producto.setStock(producto.getStock() - cantidad);
        return productoRepository.save(producto);
    }


    public Producto guardar1(Producto producto) {
        // 1. REGLA: El producto debe tener un proveedor asignado
        if (producto.getProveedorId() == null) {
            throw new IllegalArgumentException("El ID del proveedor es obligatorio.");
        }

        // 2. REGLA: Preguntarle a Proveedores si ese ID existe de verdad
        try {
            proveedorClient.obtenerPorId(producto.getProveedorId());
        } catch (feign.FeignException.NotFound e) {
            // Si Proveedores responde con 404 Not Found, abortamos la creación
            throw new IllegalArgumentException("Error: El proveedor con ID " + producto.getProveedorId() + " no existe.");
        }

        // 3. Si todo está bien, guardamos el producto
        return productoRepository.save(producto);
    }

}