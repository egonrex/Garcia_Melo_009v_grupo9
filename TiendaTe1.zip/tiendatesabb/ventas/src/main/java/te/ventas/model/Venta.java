package te.ventas.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@NoArgsConstructor 
@AllArgsConstructor
@Data
@Entity
@Table(name = "ventas")
public class Venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long usuarioId;

    @Column(nullable = false)
    private Integer total; // El valor total a pagar en pesos

    @Column(length = 50)
    private String estado; // Ej: PENDIENTE, PAGADO, CANCELADA

    @Column(nullable = false)
    private LocalDateTime fechaVenta;

    @Column(name = "codigo_cupon_aplicado", length = 50)
    private String codigoCuponAplicado;


}