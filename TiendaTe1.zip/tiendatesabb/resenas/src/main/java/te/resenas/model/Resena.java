package te.resenas.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "resenas")
public class Resena {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long productoId; // A qué producto le estamos dejando la review

    @Column(nullable = false)
    private Long usuarioId; // Quién escribió la review

    @Column(nullable = false)
    private Integer calificacion; // Ej: 1 a 5 estrellas

    @Column(length = 500)
    private String comentario;

    @Column(nullable = false)
    private LocalDateTime fechaResena;

   
}