package te.cupones.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;



@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "cupones")
public class Cupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50, unique = true)
    private String codigo; // Ej: VERANO20, CLIENTEFRECUENTE

    @Column(nullable = false)
    private Integer porcentaje; // Ej: 15 (para 15% de descuento)

    @Column(nullable = false)
    private Boolean activo; // true si se puede usar, false si ya expiró

}