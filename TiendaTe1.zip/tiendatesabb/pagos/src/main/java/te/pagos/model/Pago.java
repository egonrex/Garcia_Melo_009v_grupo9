package te.pagos.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@NoArgsConstructor 
@AllArgsConstructor
@Data
@Entity
@Table(name = "pagos")
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long ventaId; // Para saber qué venta se está pagando

    @Column(nullable = false)
    private Integer monto;

    @Column(length = 50)
    private String metodoPago; // Ej: WEBPAY, TRANSFERENCIA, EFECTIVO

    @Column(length = 50)
    private String estado; // Ej: APROBADO, RECHAZADO

    @Column(nullable = false)
    private LocalDateTime fechaTransaccion;

}