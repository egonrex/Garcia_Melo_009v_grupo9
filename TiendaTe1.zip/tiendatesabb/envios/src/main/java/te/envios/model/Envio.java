package te.envios.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor 
@AllArgsConstructor
@Data
@Entity
@Table(name = "envios")
public class Envio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long ventaId;

    @Column(nullable = false, length = 255)
    private String direccionEntrega;

    @Column(length = 50)
    private String estado; // Ej: PREPARANDO, EN_RATA, ENTREGADO

    @Column(length = 100)
    private String numeroSeguimiento; // Código del courier (Bluexpress, Starken, etc.)

}  