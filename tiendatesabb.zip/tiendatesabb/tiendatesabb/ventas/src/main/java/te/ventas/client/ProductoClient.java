package te.ventas.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import te.ventas.dto.ProductoDTO;

@FeignClient(name = "principal")
public interface ProductoClient {

    @GetMapping("/api/productos/{id}")
    ProductoDTO obtenerPorId(@PathVariable("id") Long id);
}