package te.ventas.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.ventas.client.CarritoClient;
import te.ventas.client.CuponClient;
import te.ventas.client.ProductoClient;
import te.ventas.dto.CarritoDTO;
import te.ventas.dto.CheckoutRequest;
import te.ventas.dto.CuponDTO;
import te.ventas.dto.ProductoDTO;
import te.ventas.model.Venta;
import te.ventas.model.VentaDetalle; // Asegúrate de este import
import te.ventas.repository.VentaRepository;
import te.ventas.repository.VentaDetalleRepository; // Asegúrate de este import

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private VentaDetalleRepository detalleRepository; // Nuevo

    @Autowired
    private CarritoClient carritoClient;

    @Autowired
    private ProductoClient productoClient;

    @Autowired
    private CuponClient cuponClient;

    public List<Venta> listarTodas() {
        return ventaRepository.findAll();
    }

    public Optional<Venta> buscarPorId(Long id) {
        return ventaRepository.findById(id);
    }

    public List<Venta> historialPorUsuario(Long usuarioId) {
        return ventaRepository.findByUsuarioId(usuarioId);
    }

    public Venta crearVenta(Venta venta) {
        if (venta.getFechaVenta() == null) {
            venta.setFechaVenta(LocalDateTime.now());
        }
        if (venta.getEstado() == null || venta.getEstado().isEmpty()) {
            venta.setEstado("PENDIENTE");
        }
        return ventaRepository.save(venta);
    }

    // Regla de Negocio 1: Procesar Checkout (Actualizado)
    public Venta procesarCheckout(CheckoutRequest request) {
        List<CarritoDTO> itemsCarrito = carritoClient.obtenerPorUsuario(request.getUsuarioId());
        
        if (itemsCarrito == null || itemsCarrito.isEmpty()) {
            throw new IllegalStateException("El carrito está vacío. No se puede procesar la venta.");
        }

        int totalVenta = 0;
        for (CarritoDTO item : itemsCarrito) {
            ProductoDTO producto = productoClient.obtenerPorId(item.getProductoId());
            if (producto.getStock() < item.getCantidad()) {
                throw new IllegalStateException("Stock insuficiente para el producto ID: " + item.getProductoId());
            }
            totalVenta += (producto.getPrecio() * item.getCantidad());
        }

        // Lógica de cupón
        if (request.getCodigoCupon() != null && !request.getCodigoCupon().trim().isEmpty()) {
            CuponDTO cupon = cuponClient.obtenerPorCodigo(request.getCodigoCupon());
            if (cupon != null && cupon.getActivo()) {
                totalVenta -= (totalVenta * cupon.getPorcentaje()) / 100;
            }
        }

        Venta nuevaVenta = new Venta();
        nuevaVenta.setUsuarioId(request.getUsuarioId());
        nuevaVenta.setTotal(totalVenta);
        nuevaVenta.setEstado("PENDIENTE");
        nuevaVenta.setFechaVenta(LocalDateTime.now());
        Venta ventaGuardada = ventaRepository.save(nuevaVenta);

        // Guardar detalles y limpiar carrito
        for (CarritoDTO item : itemsCarrito) {
            ProductoDTO producto = productoClient.obtenerPorId(item.getProductoId());
            VentaDetalle detalle = new VentaDetalle();
            detalle.setVentaId(ventaGuardada.getId());
            detalle.setProductoId(item.getProductoId());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(producto.getPrecio());
            detalleRepository.save(detalle);
            
            carritoClient.eliminarItem(item.getId());
        }

        return ventaGuardada;
    }

    // Regla de Negocio 2: Actualizar estado desde Pagos (Actualizado)
    public Venta actualizarEstado(Long id, String nuevoEstado) {
        Venta venta = ventaRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Venta no encontrada con ID: " + id));
        
        venta.setEstado(nuevoEstado);
        Venta ventaActualizada = ventaRepository.save(venta);

        // Si se confirma el pago, descontar stock de forma síncrona vía Feign
        if ("PAGADO".equals(nuevoEstado)) {
            List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
            for (VentaDetalle detalle : detalles) {
                productoClient.descontarStock(detalle.getProductoId(), detalle.getCantidad());
            }
        }

        return ventaActualizada;
    }

    public void eliminar(Long id) {
        ventaRepository.deleteById(id);
    }
}