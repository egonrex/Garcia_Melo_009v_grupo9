package te.ventas.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.ventas.client.CarritoClient;
import te.ventas.client.CuponClient;
import te.ventas.client.ProductoClient;
import te.ventas.dto.CarritoDTO;
import te.ventas.dto.CheckoutRequest;
import te.ventas.dto.CuponDTO;
import te.ventas.dto.ProductoDTO;
import te.ventas.model.Venta;
import te.ventas.repository.VentaRepository;

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private CarritoClient carritoClient;

    @Autowired
    private ProductoClient productoClient;

    @Autowired
    private CuponClient cuponClient;

    public List<Venta> listarTodas() {
        return ventaRepository.findAll();
    }

    public Optional<Venta> buscarPorId(Long id) {
        return ventaRepository.findById(id);
    }

    public List<Venta> historialPorUsuario(Long usuarioId) {
        return ventaRepository.findByUsuarioId(usuarioId);
    }

    public Venta crearVenta(Venta venta) {
        if (venta.getFechaVenta() == null) {
            venta.setFechaVenta(LocalDateTime.now());
        }
        if (venta.getEstado() == null || venta.getEstado().isEmpty()) {
            venta.setEstado("PENDIENTE");
        }
        return ventaRepository.save(venta);
    }

    // Regla de Negocio 1: Procesar Checkout
    public Venta procesarCheckout(CheckoutRequest request) {
        List<CarritoDTO> itemsCarrito = carritoClient.obtenerPorUsuario(request.getUsuarioId());
        
        if (itemsCarrito == null || itemsCarrito.isEmpty()) {
            throw new IllegalStateException("El carrito está vacío. No se puede procesar la venta.");
        }

        int totalVenta = 0;

        for (CarritoDTO item : itemsCarrito) {
            ProductoDTO producto;
            try {
                producto = productoClient.obtenerPorId(item.getProductoId());
            } catch (Exception e) {
                throw new IllegalStateException("El producto con ID " + item.getProductoId() + " no existe.");
            }

            if (producto.getStock() < item.getCantidad()) {
                throw new IllegalStateException("Stock insuficiente para el producto ID: " + item.getProductoId());
            }

            totalVenta += (producto.getPrecio() * item.getCantidad());
        }

        if (request.getCodigoCupon() != null && !request.getCodigoCupon().trim().isEmpty()) {
            try {
                CuponDTO cupon = cuponClient.obtenerPorCodigo(request.getCodigoCupon());
                if (cupon != null && cupon.getActivo()) {
                    int descuento = (totalVenta * cupon.getPorcentaje()) / 100;
                    totalVenta -= descuento;
                } else {
                    throw new IllegalArgumentException("El cupón ingresado no es válido o está expirado.");
                }
            } catch (Exception e) {
                throw new IllegalArgumentException("Error al validar el cupón: " + request.getCodigoCupon());
            }
        }

        Venta nuevaVenta = new Venta();
        nuevaVenta.setUsuarioId(request.getUsuarioId());
        nuevaVenta.setTotal(totalVenta);
        nuevaVenta.setEstado("PENDIENTE");
        nuevaVenta.setFechaVenta(LocalDateTime.now());
        
        Venta ventaGuardada = ventaRepository.save(nuevaVenta);

        for (CarritoDTO item : itemsCarrito) {
            carritoClient.eliminarItem(item.getId());
        }

        return ventaGuardada;
    }

    // Regla de Negocio 2: Actualizar estado desde Pagos
    public Venta actualizarEstado(Long id, String nuevoEstado) {
        Venta venta = ventaRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Venta no encontrada con ID: " + id));
        
        venta.setEstado(nuevoEstado);
        return ventaRepository.save(venta);
    }

    public void eliminar(Long id) {
        ventaRepository.deleteById(id);
    }
}