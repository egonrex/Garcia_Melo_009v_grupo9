package te.ventas.dto;

import lombok.Data;

@Data
public class CarritoDTO {
    private Long id;
    private Long productoId;
    private Integer cantidad;
}